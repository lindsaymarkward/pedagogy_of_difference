<div id="header">
	<div id="left">
    <label>Pedagogy of Difference</label>
    </div>
    <div id="right">
    	<div id="content">
        	Hi <?php echo $userRow['user_name']; ?>&nbsp;<a href="logout.php?logout">Sign Out</a>
        </div>
    </div>
</div>