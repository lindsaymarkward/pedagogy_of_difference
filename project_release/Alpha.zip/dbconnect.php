<?php
$dbh = new PDO('mysql:host=localhost;dbname=pedigree_of_difference','root','');

?>